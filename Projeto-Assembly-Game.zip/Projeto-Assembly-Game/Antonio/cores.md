# Cores do Jogo

## Cenário

Fundo -> #a5abc5

Pilares -> #636194

Letreiros -> #b1ba93

Borda das janelas -> #636194

Luz das janelas -> #e5bc43

## NPCs

Contorno dos orbes -> #00439d

Cruz dos orbes -> #2e24bd


## Protagonista

Azul principal -> #4bb8e3

Azul contorno e nariz -> #0674cb

Chifres -> #9f9b90

Rosa detalhes -> #b16bb5
